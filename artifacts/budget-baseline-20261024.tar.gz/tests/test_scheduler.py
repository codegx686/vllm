"""Integration tests against the installed vLLM scheduler, using its real KV allocator.

Fixture construction follows vLLM v0.22.1 tests/v1/core/utils.py (Apache-2.0).
No model execution/GPU memory allocation is needed for these scheduler tests.
"""
import json
import os
import pytest
torch = pytest.importorskip('torch')
pytest.importorskip('vllm')
from vllm.config import CacheConfig, ModelConfig, SchedulerConfig, VllmConfig
from vllm.sampling_params import SamplingParams
from vllm.v1.core.sched.scheduler import Scheduler
from vllm.v1.kv_cache_interface import FullAttentionSpec, KVCacheConfig, KVCacheGroupSpec
from vllm.v1.request import Request, RequestStatus
from vllm.v1.outputs import ModelRunnerOutput
from vllm.v1.structured_output import StructuredOutputManager
from adaptive_budget.scheduler import AdaptiveBudgetScheduler


@pytest.fixture
def make_scheduler(monkeypatch, tmp_path):
    def make(mode='static', budget=1024, cls=AdaptiveBudgetScheduler, blocks=4096):
        path = tmp_path / f'{mode}.json'
        path.write_text(json.dumps(dict(mode=mode, static_budget=budget)))
        monkeypatch.setenv('AB_CONFIG', str(path))
        model = ModelConfig(model=os.environ['AB_TEST_MODEL'], dtype='bfloat16', max_model_len=16384)
        sc = SchedulerConfig(max_num_seqs=16, max_num_batched_tokens=8192,
            max_model_len=16384, enable_chunked_prefill=True, async_scheduling=False,
            is_encoder_decoder=False)
        cache = CacheConfig(block_size=16, enable_prefix_caching=False)
        cache.num_gpu_blocks = blocks
        cfg = VllmConfig(model_config=model, scheduler_config=sc, cache_config=cache)
        kv = KVCacheConfig(num_blocks=blocks, kv_cache_tensors=[], kv_cache_groups=[
            KVCacheGroupSpec(['layer'], FullAttentionSpec(block_size=16, num_kv_heads=1,
                head_size=1, dtype=torch.float32))])
        return cls(vllm_config=cfg, kv_cache_config=kv, block_size=16,
            structured_output_manager=StructuredOutputManager(cfg), log_stats=False)
    return make


def request(rid, n):
    return Request(request_id=rid, prompt_token_ids=[42] * n,
        sampling_params=SamplingParams(max_tokens=32, ignore_eos=True),
        pooling_params=None, mm_features=None)


def test_off_has_native_schedule_and_cancellation(make_scheduler):
    a, b = make_scheduler(mode='off'), make_scheduler(cls=Scheduler)
    for s in [a, b]:
        for i, n in enumerate([100, 3000, 7000]):
            s.add_request(request(str(i), n))
    assert a.schedule().num_scheduled_tokens == b.schedule().num_scheduled_tokens
    for s in [a, b]:
        s.finish_requests(['0', '1', '2'], RequestStatus.FINISHED_ABORTED)
        assert s.get_num_unfinished_requests() == 0


@pytest.mark.parametrize('budget', [512, 1024, 2048, 4096, 8192])
def test_real_allocator_respects_budget_and_restores_capacity(make_scheduler, budget):
    s = make_scheduler(budget=budget)
    s.add_request(request('long', 12000))
    out = s.schedule()
    assert out.num_scheduled_tokens == {'long': budget}
    assert s.max_num_scheduled_tokens == 8192
    s.finish_requests('long', RequestStatus.FINISHED_ABORTED)
    s._ab_observe(1)
    assert not s.ab_progress


def test_capacity_restored_when_native_schedule_raises(make_scheduler, monkeypatch):
    s = make_scheduler()
    def fail(_):
        raise RuntimeError('simulated allocator failure')
    monkeypatch.setattr(Scheduler, 'schedule', fail)
    with pytest.raises(RuntimeError):
        s.schedule()
    assert s.max_num_scheduled_tokens == 8192


def test_stall_progress_and_blocked_request_filter(make_scheduler):
    s = make_scheduler()
    r = request('r', 4000)
    s.add_request(r)
    assert s._ab_observe(10).oldest_stall_ms == 0
    assert s._ab_observe(11).oldest_stall_ms == 1000
    r.num_computed_tokens = 100
    assert s._ab_observe(12).oldest_stall_ms == 0
    r.num_computed_tokens = 0
    r.status = RequestStatus.PREEMPTED
    assert s._ab_observe(13).oldest_stall_ms == 1000
    r.status = RequestStatus.WAITING_FOR_STRUCTURED_OUTPUT_GRAMMAR
    assert s._ab_observe(14).prefills == 0
    assert not s.ab_progress


@pytest.mark.parametrize('mode', ['off', 'adaptive'])
def test_kv_pressure_preempts_and_resumes_without_losing_request(make_scheduler, mode):
    s = make_scheduler(mode=mode, blocks=11)
    a, b = request('a', 80), request('b', 80)
    s.add_request(a)
    first = s.schedule()
    s.add_request(b)
    s.schedule()
    assert s.kv_cache_manager.block_pool.get_num_free_blocks() == 0
    model_out = ModelRunnerOutput(req_ids=['a'], req_id_to_index={'a': 0},
        sampled_token_ids=[[100]], logprobs=None, prompt_logprobs_dict={}, pooler_output=[])
    s.update_from_output(first, model_out)
    s.schedule()
    assert b.status == RequestStatus.PREEMPTED
    assert b.request_id in s.requests
    s.finish_requests('a', RequestStatus.FINISHED_ABORTED)
    resumed = s.schedule()
    assert resumed.num_scheduled_tokens['b'] == 80
    assert b.status == RequestStatus.RUNNING
    s.finish_requests('b', RequestStatus.FINISHED_ABORTED)
    s._ab_observe(20)
    assert s.get_num_unfinished_requests() == 0
    assert not s.ab_progress
    assert s.kv_cache_manager.block_pool.get_num_free_blocks() == 10
