"""A pure state machine: no GPU calls, wall-clock assumptions, or queue mutation.

P-PAS pressure switching is an attributed comparator, not an original algorithm.
The adaptive policy adds hysteresis, minimum residence, and a rate-limited
budget boost for prefills that have not made scheduling progress.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class PolicyConfig:
    mode: str = "adaptive"
    high_budget: int = 8192
    low_budget: int = 1024
    static_budget: int = 8192
    enter_prefills: int = 2
    exit_prefills: int = 0
    min_dwell_steps: int = 4
    guard_enabled: bool = True
    max_stall_ms: float = 250.0
    guard_budget: int = 4096
    guard_interval_steps: int = 8

    def validate(self, engine_capacity: int) -> None:
        if self.mode not in {"off", "static", "ppas", "adaptive"}:
            raise ValueError(f"Unknown policy mode: {self.mode}")
        if engine_capacity < 1:
            raise ValueError("Engine capacity must be positive")
        if self.mode == "off":
            return
        if self.mode == "static":
            if not 1 <= self.static_budget <= engine_capacity:
                raise ValueError("Static budget exceeds engine capacity or is nonpositive")
            return
        if not 1 <= self.low_budget <= self.high_budget <= engine_capacity:
            raise ValueError("Require 1 <= low_budget <= high_budget <= engine capacity")
        if not self.low_budget <= self.guard_budget <= self.high_budget:
            raise ValueError("Guard budget must lie between low and high budgets")
        if not 0 <= self.exit_prefills < self.enter_prefills:
            raise ValueError("Require 0 <= exit_prefills < enter_prefills")
        if self.min_dwell_steps < 0 or self.guard_interval_steps < 1:
            raise ValueError("Invalid residence/cooldown step count")
        if self.max_stall_ms <= 0:
            raise ValueError("Stall threshold must be positive")


@dataclass(frozen=True)
class Observation:
    prefills: int
    decodes: int
    oldest_stall_ms: float = 0.0
    pending_prefill_tokens: int = 0


@dataclass(frozen=True)
class Decision:
    budget: int
    state: str
    reason: str
    switched: bool = False
    guard_fired: bool = False


class BudgetController:
    def __init__(self, config: PolicyConfig, engine_capacity: int):
        config.validate(engine_capacity)
        self.config = config
        self.engine_capacity = engine_capacity
        self.limited = False
        self.step = 0
        self.last_switch = -config.min_dwell_steps
        self.last_guard = -config.guard_interval_steps
        self.switches = 0
        self.guard_fires = 0

    def decide(self, obs: Observation) -> Decision:
        if min(obs.prefills, obs.decodes, obs.oldest_stall_ms, obs.pending_prefill_tokens) < 0:
            raise ValueError("Observations must be nonnegative")
        cfg = self.config
        self.step += 1
        if cfg.mode == "off":
            return Decision(self.engine_capacity, "OFF", "native")
        if cfg.mode == "static":
            return Decision(cfg.static_budget, "STATIC", "fixed")

        previous = self.limited
        if cfg.mode == "ppas":
            self.limited = obs.prefills >= cfg.enter_prefills and obs.decodes > 0
            reason = "pressure" if self.limited else "open"
        elif obs.decodes == 0 or obs.prefills == 0:
            # No mixed-phase interference: bypass residence and release capacity.
            self.limited = False
            reason = "no_mixed_work"
        elif self.step - self.last_switch >= cfg.min_dwell_steps:
            if not self.limited and obs.prefills >= cfg.enter_prefills:
                self.limited = True
                reason = "enter_pressure"
            elif self.limited and obs.prefills <= cfg.exit_prefills:
                self.limited = False
                reason = "exit_pressure"
            else:
                reason = "hysteresis_hold"
        else:
            reason = "residence_hold"

        switched = previous != self.limited
        if switched:
            self.last_switch = self.step
            self.switches += 1
        budget = cfg.low_budget if self.limited else cfg.high_budget
        guard = (
            cfg.mode == "adaptive"
            and cfg.guard_enabled
            and self.limited
            and obs.prefills > 0
            and obs.oldest_stall_ms >= cfg.max_stall_ms
            and self.step - self.last_guard >= cfg.guard_interval_steps
        )
        if guard:
            budget = max(budget, cfg.guard_budget)
            self.last_guard = self.step
            self.guard_fires += 1
            reason = "stalled_prefill_boost"
        # A boost creates an opportunity; it is not an admission/fairness guarantee.
        return Decision(budget, "LIMITED" if self.limited else "OPEN", reason, switched, guard)

