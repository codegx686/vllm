"""vLLM 0.22.1 synchronous V1 scheduler extension.

Integration uses scheduler_cls and super().schedule(), retaining native KV
allocation, preemption, cancellation, and request lifecycle handling.
Configure once at startup through AB_CONFIG, a JSON file path.
"""
import atexit
from dataclasses import asdict
import json
import os
from pathlib import Path
import time

from vllm.v1.core.sched.scheduler import Scheduler
from vllm.v1.request import RequestStatus

from .controller import BudgetController, Observation, PolicyConfig


class AdaptiveBudgetScheduler(Scheduler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        raw = {}
        if os.environ.get("AB_CONFIG"):
            raw = json.loads(Path(os.environ["AB_CONFIG"]).read_text())
        trace_path = raw.pop("trace_path", None)
        self.ab_config = PolicyConfig(**raw)
        self.ab_capacity = self.max_num_scheduled_tokens
        self.ab_controller = BudgetController(self.ab_config, self.ab_capacity)
        if self.ab_config.mode != "off":
            if self.scheduler_config.async_scheduling:
                raise ValueError("Adaptive budget lab currently requires async_scheduling=False")
            if self.vllm_config.speculative_config is not None:
                raise ValueError("Speculative decoding is outside the validated scope")
            if not self.scheduler_config.enable_chunked_prefill:
                raise ValueError("Adaptive budgets require chunked prefill")
            if self.parallel_config.world_size != 1:
                raise ValueError("This experiment is validated for one GPU only")
        self.ab_progress = {}
        self.ab_trace = None
        if trace_path:
            path = Path(trace_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            self.ab_trace = path.open("w", encoding="utf-8", buffering=65536)
            self.ab_trace.write(json.dumps({"type": "config", "pid": os.getpid(),
                "capacity": self.ab_capacity, "config": asdict(self.ab_config)}) + "\n")
            self.ab_trace.flush()
            atexit.register(self.ab_trace.close)

    def _ab_observe(self, now):
        prefills = decodes = remaining = 0
        oldest_stall = 0.0
        live = set()
        for req_id, req in self.requests.items():
            # Exclude blocked remote-KV/grammar requests and completed requests.
            if req.status not in {RequestStatus.WAITING, RequestStatus.RUNNING, RequestStatus.PREEMPTED}:
                continue
            if req.num_computed_tokens < req.num_prompt_tokens:
                prefills += 1
                remaining += req.num_prompt_tokens - req.num_computed_tokens
                live.add(req_id)
                old_count, last_progress = self.ab_progress.get(req_id, (req.num_computed_tokens, now))
                # A rollback from preemption is not forward progress.
                if req.num_computed_tokens > old_count:
                    last_progress = now
                self.ab_progress[req_id] = (req.num_computed_tokens, last_progress)
                oldest_stall = max(oldest_stall, (now - last_progress) * 1000)
            elif req.status == RequestStatus.RUNNING:
                decodes += 1
        for req_id in self.ab_progress.keys() - live:
            del self.ab_progress[req_id]
        return Observation(prefills, decodes, oldest_stall, remaining)

    def schedule(self):
        if self.ab_config.mode == "off":
            return super().schedule()
        started = time.perf_counter_ns()
        obs = self._ab_observe(time.monotonic())
        decision = self.ab_controller.decide(obs)
        decision_us = (time.perf_counter_ns() - started) / 1000
        saved_budget = self.max_num_scheduled_tokens
        self.max_num_scheduled_tokens = decision.budget
        try:
            result = super().schedule()
        finally:
            self.max_num_scheduled_tokens = saved_budget
        scheduled = sum(result.num_scheduled_tokens.values())
        if scheduled > decision.budget:
            raise AssertionError("Native scheduler exceeded selected token budget")
        if self.ab_trace is not None:
            record = {"type": "step", "step": self.ab_controller.step,
                "at": time.monotonic(), **asdict(obs), **asdict(decision),
                "scheduled_tokens": scheduled,
                "scheduled_requests": len(result.num_scheduled_tokens),
                "preempted_requests": len(result.preempted_req_ids),
                "switches_total": self.ab_controller.switches,
                "guards_total": self.ab_controller.guard_fires,
                "decision_us": decision_us}
            self.ab_trace.write(json.dumps(record, separators=(",", ":")) + "\n")
            if not obs.prefills or self.ab_controller.step % 128 == 0:
                self.ab_trace.flush()
        return result
